rootProject.name = "Lab6Tema"

