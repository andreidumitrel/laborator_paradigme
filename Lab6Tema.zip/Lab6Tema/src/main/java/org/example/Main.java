package org.example;

import java.io.*;
import java.util.*;
import java.util.Collections;

public class Main {
    public static void main(String[] args) throws IOException {
                List<String> lines = readLines("input_tema.txt");

                Collections.sort(lines);

                writeLines("output_tema.txt", lines);
            }

            public static List<String> readLines(String filename) throws IOException {
                List<String> lines = new ArrayList<>();
                try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        lines.add(line);
                    }
                }
                return lines;
            }

            public static void writeLines(String filename, List<String> lines) throws IOException {
                Map<String, Integer> phoneNumbers = new HashMap<>();
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
                    for (String line : lines) {
                        String[] parts = line.split(" ");
                        String phoneNumber = parts[2];
                        phoneNumbers.put(phoneNumber, phoneNumbers.getOrDefault(phoneNumber, 0) + 1);
                        if (phoneNumbers.get(phoneNumber) >= 2) {
                            line += "*";
                        }
                        writer.write(line);
                        writer.newLine();
                    }
                }
    }
}

